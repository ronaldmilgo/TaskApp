import UIKit

// The Task model
struct Task: Codable {

    // The task's title
    var title: String

    // An optional note
    var note: String?

    // The due date by which the task should be completed
    var dueDate: Date

    // Initialize a new task
    init(title: String, note: String? = nil, dueDate: Date = Date()) {
        self.title = title
        self.note = note
        self.dueDate = dueDate
    }

    // A boolean to determine if the task has been completed. Defaults to `false`
    var isComplete: Bool = false {
        // Any time a task is completed, update the completedDate accordingly.
        didSet {
            if isComplete {
                completedDate = Date() // Set the completed date to "right now" when marked complete.
            } else {
                completedDate = nil
            }
        }
    }

    // The date the task was completed
    private(set) var completedDate: Date?

    // The date the task was created
    private(set) var createdDate: Date = Date()

    // An id (Universal Unique Identifier) used to identify a task.
    private(set) var id: String = UUID().uuidString
}

// MARK: - Task + UserDefaults
extension Task {

    // Given an array of tasks, encodes them to data and saves to UserDefaults.
    static func save(_ tasks: [Task]) {
        let encoder = JSONEncoder()
        do {
            // Encode the tasks array to data
            let data = try encoder.encode(tasks)
            // Save to UserDefaults
            UserDefaults.standard.set(data, forKey: "tasks")
        } catch {
            print("Failed to encode tasks: \(error)")
        }
    }

    // Retrieve an array of saved tasks from UserDefaults.
    static func getTasks() -> [Task] {
        if let data = UserDefaults.standard.data(forKey: "tasks") {
            let decoder = JSONDecoder()
            do {
                // Decode the data into an array of tasks
                let tasks = try decoder.decode([Task].self, from: data)
                return tasks
            } catch {
                print("Failed to decode tasks: \(error)")
            }
        }
        return [] // Return an empty array if no tasks are found in UserDefaults
    }

    // Add a new task or update an existing task with the current task.
    func save() {
        var tasks = Task.getTasks()
        if let index = tasks.firstIndex(where: { $0.id == self.id }) {
            // Update existing task
            tasks[index] = self
        } else {
            // Add new task
            tasks.append(self)
        }
        Task.save(tasks) // Re-save the updated tasks array to UserDefaults
    }
}
